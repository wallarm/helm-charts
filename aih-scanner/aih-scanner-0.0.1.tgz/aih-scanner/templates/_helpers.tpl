{{/* Chart name */}}
{{- define "higgs-scanner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Fullname: release-chart (with overrides) */}}
{{- define "higgs-scanner.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Namespace helper */}}
{{- define "higgs-scanner.namespace" -}}
{{- .Values.namespace.name | default .Release.Namespace }}
{{- end }}

{{/* Chart label value: name-version */}}
{{- define "higgs-scanner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Image tag: prefer .Values.image.tag, fall back to .Chart.AppVersion */}}
{{- define "higgs-scanner.imageTag" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{/* Resource metadata labels (app.kubernetes.io/*) */}}
{{- define "higgs-scanner.labels" -}}
helm.sh/chart: {{ include "higgs-scanner.chart" . }}
app.kubernetes.io/name: {{ include "higgs-scanner.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ include "higgs-scanner.imageTag" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aih
{{- end }}

{{/* Pod-safe labels (custom domain to bypass EKS Auto Mode restrictions) */}}
{{- define "higgs-scanner.podLabels" -}}
higgs.wallarm.com/name: {{ include "higgs-scanner.name" . }}
higgs.wallarm.com/instance: {{ .Release.Name }}
higgs.wallarm.com/managed-by: {{ .Release.Service }}
higgs.wallarm.com/version: {{ include "higgs-scanner.imageTag" . | quote }}
higgs.wallarm.com/part-of: aih
{{- end }}

{{/* Selector labels for DaemonSet matchLabels — immutable after first deploy */}}
{{- define "higgs-scanner.selectorLabels" -}}
higgs.wallarm.com/name: {{ include "higgs-scanner.name" . }}
higgs.wallarm.com/instance: {{ .Release.Name }}
{{- end }}

{{/* ServiceAccount name */}}
{{- define "higgs-scanner.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- include "higgs-scanner.fullname" . }}
{{- end }}
{{- end }}

{{/* Secret name for scanner private key */}}
{{- define "higgs-scanner.secretName" -}}
{{- if .Values.existingSecret.name }}
{{- .Values.existingSecret.name }}
{{- else }}
{{- printf "%s-private-key" (include "higgs-scanner.fullname" .) }}
{{- end }}
{{- end }}

{{/* Scanner config port (single source of truth) */}}
{{- define "higgs-scanner.port" -}}
{{- .Values.config.port | default 19090 }}
{{- end }}
