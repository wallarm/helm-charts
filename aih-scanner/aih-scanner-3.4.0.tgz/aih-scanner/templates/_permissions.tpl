{{/*
  `permissions:` (permission opt-out plan §3.5): what the customer GRANTS the scanner pods. Unset =
  the profile's default grant, exactly as before. A withheld grant is rendered without the missing
  piece — never a failed install: the scanner measures what it got (permprobe) and reports each
  feature that is off, with the grant that turns it back on.

    permissions.hostPID / hostNetwork   false = not rendered
    permissions.linuxCaps               list = the only capabilities any container may add
                                        (BPF/PERFMON stand in for SYS_ADMIN when listed)
    permissions.hostPaths               map host path -> false = an empty dir in its place
    permissions.podSecurity             baseline | restricted = a pod spec that PSA level admits:
                                        no host namespaces, no hostPath, no added capabilities
                                        (restricted also: non-root, drop ALL, no escalation)
*/}}

{{- define "higgs-scanner.permissions" -}}
{{- toJson (.Values.permissions | default dict) -}}
{{- end -}}

{{/* "true" when podSecurity confines the pods to baseline or restricted. */}}
{{- define "higgs-scanner.psaConfined" -}}
{{- $p := fromJson (include "higgs-scanner.permissions" .) -}}
{{- if has (toString ($p.podSecurity | default "")) (list "baseline" "restricted") }}true{{ end -}}
{{- end -}}

{{- define "higgs-scanner.psaRestricted" -}}
{{- $p := fromJson (include "higgs-scanner.permissions" .) -}}
{{- if eq (toString ($p.podSecurity | default "")) "restricted" }}true{{ end -}}
{{- end -}}

{{/* (list . "hostPID"|"hostNetwork") -> "true" when granted. */}}
{{- define "higgs-scanner.hostNsGranted" -}}
{{- $root := index . 0 -}}
{{- $p := fromJson (include "higgs-scanner.permissions" $root) -}}
{{- if and (not (include "higgs-scanner.psaConfined" $root)) (ne (toString (index $p (index . 1))) "false") }}true{{ end -}}
{{- end -}}

{{/* (list . "/proc") -> "true" when that host path may be mounted. */}}
{{- define "higgs-scanner.hostPathGranted" -}}
{{- $root := index . 0 -}}
{{- $p := fromJson (include "higgs-scanner.permissions" $root) -}}
{{- $paths := $p.hostPaths | default dict -}}
{{- if and (not (include "higgs-scanner.psaConfined" $root)) (ne (toString (index $paths (index . 1))) "false") }}true{{ end -}}
{{- end -}}

{{/* (list . name path type) -> one volume: the hostPath, or an empty dir in its place. */}}
{{- define "higgs-scanner.hostPathVolume" -}}
{{- $root := index . 0 -}}
- name: {{ index . 1 }}
{{- if include "higgs-scanner.hostPathGranted" (list $root (index . 2)) }}
  hostPath:
    path: {{ index . 2 }}
    type: {{ index . 3 }}
{{- else }}
  # permissions: hostPath {{ index . 2 }} is not granted — an empty dir in its place; the scanner
  # reports the features that need it as off.
  emptyDir: {}
{{- end }}
{{- end -}}

{{/* (list . addList) -> JSON list: the capabilities a container may add under `permissions`. */}}
{{- define "higgs-scanner.grantedCaps" -}}
{{- $root := index . 0 -}}
{{- $want := index . 1 -}}
{{- $p := fromJson (include "higgs-scanner.permissions" $root) -}}
{{- if include "higgs-scanner.psaConfined" $root -}}
[]
{{- else if kindIs "slice" $p.linuxCaps -}}
{{- $allowed := $p.linuxCaps -}}
{{- $out := list -}}
{{- range $c := $want }}{{ if has $c $allowed }}{{ $out = append $out $c }}{{ end }}{{ end -}}
{{- if and (has "SYS_ADMIN" $want) (not (has "SYS_ADMIN" $allowed)) -}}
{{- range $c := list "BPF" "PERFMON" }}{{ if has $c $allowed }}{{ $out = append $out $c }}{{ end }}{{ end -}}
{{- end -}}
{{- toJson (uniq $out) -}}
{{- else -}}
{{- toJson $want -}}
{{- end -}}
{{- end -}}

{{/* (list . securityContextDict) -> the context with `permissions` applied (YAML). */}}
{{- define "higgs-scanner.permSecurityContext" -}}
{{- $root := index . 0 -}}
{{- $sc := index . 1 -}}
{{- $caps := $sc.capabilities | default dict -}}
{{- $add := fromJsonArray (include "higgs-scanner.grantedCaps" (list $root ($caps.add | default list))) -}}
{{- $newCaps := dict "add" $add -}}
{{- if hasKey $caps "drop" }}{{ $_ := set $newCaps "drop" $caps.drop }}{{ end -}}
{{- $_ := set $sc "capabilities" $newCaps -}}
{{- if include "higgs-scanner.psaConfined" $root -}}
{{- $_ := set $sc "privileged" false -}}
{{- $_ := set $sc "allowPrivilegeEscalation" false -}}
{{- /* No Unconfined under PSA; and no explicit RuntimeDefault either (kubelet rejects it on nodes
       without AppArmor) — unset is the runtime default where AppArmor exists. */ -}}
{{- $_ := unset $sc "appArmorProfile" -}}
{{- $_ := set $sc "seccompProfile" (dict "type" "RuntimeDefault") -}}
{{- if include "higgs-scanner.psaRestricted" $root -}}
{{- $_ := set $sc "capabilities" (dict "drop" (list "ALL")) -}}
{{- $_ := set $sc "runAsNonRoot" true -}}
{{- $_ := set $sc "runAsUser" 65532 -}}
{{- $_ := set $sc "runAsGroup" 65532 -}}
{{- end -}}
{{- end -}}
{{- if and (kindIs "map" $sc.capabilities) (not $sc.capabilities.add) -}}
{{- $_ := unset $sc.capabilities "add" -}}
{{- end -}}
{{- toYaml $sc -}}
{{- end -}}

{{/* The kernel-lane-cleanup init container runs only when it can do its job (NET_ADMIN, eBPF
     privilege and the bpffs mount); otherwise it would hold the pod in Init:Error. */}}
{{- define "higgs-scanner.cleanupInitGranted" -}}
{{- $caps := fromJsonArray (include "higgs-scanner.grantedCaps" (list . (list "SYS_ADMIN" "SYS_PTRACE" "NET_ADMIN"))) -}}
{{- if and (has "NET_ADMIN" $caps) (or (has "SYS_ADMIN" $caps) (has "BPF" $caps)) (include "higgs-scanner.hostPathGranted" (list . "/sys/fs/bpf")) }}true{{ end -}}
{{- end -}}

{{/* Containers that add nothing (webhook, classifier, pool): under podSecurity restricted they
     still need the restricted fields. Renders a `securityContext:` block, or nothing. */}}
{{- define "higgs-scanner.psaContainerContext" -}}
{{- if include "higgs-scanner.psaRestricted" . }}
securityContext:
  allowPrivilegeEscalation: false
  runAsNonRoot: true
  runAsUser: 65532
  runAsGroup: 65532
  capabilities:
    drop: ["ALL"]
  seccompProfile:
    type: RuntimeDefault
{{- end }}
{{- end -}}

{{/* The bpf-pin-cleanup pre-delete hook needs the host PID namespace, the bpffs mount and
     NET_ADMIN + eBPF privilege; without them there are no pins to remove (the kernel lane could
     not have pinned anything), and a hook the cluster rejects would fail `helm uninstall`. */}}
{{- define "higgs-scanner.pinCleanupGranted" -}}
{{- if and (include "higgs-scanner.hostNsGranted" (list . "hostPID")) (include "higgs-scanner.cleanupInitGranted" .) }}true{{ end -}}
{{- end -}}

{{/* (list . probe) -> the probe; without hostNetwork its loopback `host` is dropped (kubelet's
     127.0.0.1 is the node's, not the pod's — the probe would never reach the scanner). */}}
{{- define "higgs-scanner.probe" -}}
{{- $root := index . 0 -}}
{{- $pr := deepCopy (index . 1) -}}
{{- if and (not (include "higgs-scanner.hostNsGranted" (list $root "hostNetwork"))) (kindIs "map" $pr.httpGet) (eq (toString $pr.httpGet.host) "127.0.0.1") -}}
{{- $_ := unset $pr.httpGet "host" -}}
{{- end -}}
{{- toYaml $pr -}}
{{- end -}}

{{/* permissions.watchNamespaces as a JSON list ([] = cluster-wide). Non-empty: the scanner's RBAC
     is a Role + RoleBinding per listed namespace (no ClusterRole for its capabilities), cluster-
     scoped kinds are not granted, and WATCH_NAMESPACES limits every watch and list to them. */}}
{{- define "higgs-scanner.watchNamespaces" -}}
{{- $p := fromJson (include "higgs-scanner.permissions" .) -}}
{{- toJson ($p.watchNamespaces | default list) -}}
{{- end -}}

{{/* Kinds a namespaced Role cannot grant (cluster-scoped). */}}
{{- define "higgs-scanner.clusterScopedResources" -}}
["nodes","namespaces","persistentvolumes","customresourcedefinitions","clusterroles","clusterrolebindings","ingressclasses","validatingadmissionpolicies","mutatingwebhookconfigurations"]
{{- end -}}

{{/* The priority class to render, or "" (permission plan §2.2). system-node-critical /
     system-cluster-critical need a quota for them outside kube-system on GKE (Autopilot refused
     every scanner pod: "insufficient quota to match these scopes", 2026-11-11). Withheld by
     permissions.criticalPriority: false or a podSecurity preset; a non-system class is kept. */}}
{{- define "higgs-scanner.priorityClassName" -}}
{{- $pc := toString (.Values.priorityClassName | default "") -}}
{{- $p := fromJson (include "higgs-scanner.permissions" .) -}}
{{- $critical := hasPrefix "system-" $pc -}}
{{- if and $critical (or (include "higgs-scanner.psaConfined" .) (eq (toString $p.criticalPriority) "false")) -}}
{{- else -}}{{ $pc }}{{- end -}}
{{- end -}}
