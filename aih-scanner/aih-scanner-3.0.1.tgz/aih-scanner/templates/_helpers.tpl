{{/* Chart name */}}
{{- define "higgs-scanner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Fullname: release-chart (with overrides) */}}
{{- define "higgs-scanner.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Namespace helper */}}
{{- define "higgs-scanner.namespace" -}}
{{- .Values.namespace.name | default .Release.Namespace }}
{{- end }}

{{/* Chart label value: name-version */}}
{{- define "higgs-scanner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Image tag: prefer .Values.image.tag, fall back to .Chart.AppVersion */}}
{{- define "higgs-scanner.imageTag" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{/* Resource metadata labels (app.kubernetes.io/*) */}}
{{- define "higgs-scanner.labels" -}}
helm.sh/chart: {{ include "higgs-scanner.chart" . }}
app.kubernetes.io/name: {{ include "higgs-scanner.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ include "higgs-scanner.imageTag" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aih
{{- end }}

{{/* Pod labels — includes selector labels plus additional metadata */}}
{{- define "higgs-scanner.podLabels" -}}
app: {{ include "higgs-scanner.name" . }}
release: {{ .Release.Name }}
higgs.wallarm.com/name: {{ include "higgs-scanner.name" . }}
higgs.wallarm.com/instance: {{ .Release.Name }}
higgs.wallarm.com/managed-by: {{ .Release.Service }}
higgs.wallarm.com/version: {{ include "higgs-scanner.imageTag" . | quote }}
higgs.wallarm.com/part-of: aih
{{- end }}

{{/* Selector labels for DaemonSet matchLabels — immutable after first deploy.
    Must match the original chart's selectors (app + release) for upgrade compatibility. */}}
{{- define "higgs-scanner.selectorLabels" -}}
app: {{ include "higgs-scanner.name" . }}
release: {{ .Release.Name }}
{{- end }}

{{/* ServiceAccount name */}}
{{- define "higgs-scanner.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- include "higgs-scanner.fullname" . }}
{{- end }}
{{- end }}

{{/* Names the scanner may read and write as a Secret: the MITM CA secret, which the scanner
    replicates into every onboarded namespace and the proxy creates on first start. The Go
    daemon uses the fixed name aih-scanner-ca; caSecretName renames what the chart creates,
    the proxy mounts and the webhook injects — so both are listed when they differ.
    Rendered as a JSON array (one line) for RBAC resourceNames and the CEL `in` list. */}}
{{- define "higgs-scanner.caSecretNames" -}}
{{- list "aih-scanner-ca" (.Values.caSecretName | default "aih-scanner-ca") | uniq | toJson -}}
{{- end }}

{{/* Image pull secrets for a pod: its own list (or the global imagePullSecrets) plus
    extraImagePullSecrets, as a YAML array. Every workload, hooks included, uses this — a private
    mirror must reach all of them (the webhook ignored extraImagePullSecrets, the hooks both). */}}
{{- define "higgs-scanner.pullSecretList" -}}
{{- $own := .own | default .root.Values.imagePullSecrets | default list -}}
{{- concat $own (.root.Values.extraImagePullSecrets | default list) | toYaml -}}
{{- end }}

{{/* gitops: true — the Secrets the chart would otherwise generate in templates (`lookup`, which
    `helm template` cannot do), as `kind=name` arguments for the bootstrap Job
    (bootstrap-secrets.yaml). The same conditions as the templates they replace. JSON array. */}}
{{- define "higgs-scanner.bootstrapSecrets" -}}
{{- $fn := include "higgs-scanner.fullname" . -}}
{{- $out := list -}}
{{- if (include "higgs-scanner.cap" (list . "proxy")) -}}
{{- $out = append $out (printf "token=%s-proxy-mgmt-token" $fn) -}}
{{- if not .Values.proxy.ca.existingSecret -}}
{{- $out = append $out (printf "ca=%s" (.Values.caSecretName | default "aih-scanner-ca")) -}}
{{- end -}}
{{- end -}}
{{- if and (include "higgs-scanner.classifierOn" $) .Values.classifier.pool.enabled -}}
{{- $out = append $out (printf "token=%s-classifier-pool-token" $fn) -}}
{{- end -}}
{{- if and .Values.gitops (include "higgs-scanner.cap" (list . "webhook")) (not .Values.webhook.tls.certManager.enabled) (not (or .Values.webhook.tls.existingSecret .Values.webhook.tls.secretName)) -}}
{{- $wh := printf "%s-webhook" $fn -}}
{{- $ns := include "higgs-scanner.namespace" . -}}
{{- $out = append $out (printf "webhook-tls=%s-tls@%s,%s.%s,%s.%s.svc,%s.%s.svc.cluster.local" $wh $wh $wh $ns $wh $ns $wh $ns) -}}
{{- end -}}
{{- toJson $out -}}
{{- end }}

{{/* The bootstrap Job's ServiceAccount, as the API server names it in admission requests. */}}
{{- define "higgs-scanner.bootstrapUser" -}}
{{- printf "system:serviceaccount:%s:%s-bootstrap" (include "higgs-scanner.namespace" .) (include "higgs-scanner.fullname" .) -}}
{{- end }}

{{/* Secret name for scanner private key */}}
{{- define "higgs-scanner.secretName" -}}
{{- if .Values.existingSecret.name }}
{{- .Values.existingSecret.name }}
{{- else }}
{{- printf "%s-private-key" (include "higgs-scanner.fullname" .) }}
{{- end }}
{{- end }}

{{/* Scanner config port (single source of truth) */}}
{{- define "higgs-scanner.port" -}}
{{- .Values.config.port | default 19090 }}
{{- end }}

{{/* Host path to the containerd socket (canonical key: config.containerdSocketPath).
    Falls back to agents.containerdSocketPath, where charts 2.0.0–2.6.0 accidentally
    shipped the key. `required` fails at template time instead of rendering an empty
    hostPath.path that only server-side apply rejects. */}}
{{- define "higgs-scanner.containerdSocketPath" -}}
{{- $agents := .Values.agents | default dict -}}
{{- required "config.containerdSocketPath is required (host path to the containerd socket)" (.Values.config.containerdSocketPath | default $agents.containerdSocketPath) }}
{{- end }}

{{/*
The classifier sidecar image: a pinned tag wins; otherwise the code-only image published with
this scanner release, "<appVersion>-classifier".
*/}}
{{- define "higgs-scanner.classifierImage" -}}
{{- $tag := .Values.classifier.image.tag | default (printf "%s-classifier" (include "higgs-scanner.imageTag" .)) -}}
{{- printf "%s:%s" .Values.classifier.image.repository $tag -}}
{{- end }}

{{/*
Where the sidecar's model comes from: backend (downloaded by the scanner — default), baked
(in the image) or volume (ops-supplied). The deprecated bundleBaked=true still means baked.
*/}}
{{- define "higgs-scanner.classifierBundleSource" -}}
{{- if .Values.classifier.bundleBaked -}}baked{{- else -}}{{- .Values.classifier.bundleSource | default "backend" -}}{{- end -}}
{{- end }}

{{/*
The scanner key as a file, re-read on change by the Go binaries (config.KeySource) so a
rotated key reaches them without a restart. Directory mount — kubelet refreshes it; a
subPath mount would never update. Use all three together, guarded by the same condition
as the SCANNER_PRIVATE_KEY env var.
*/}}
{{/* Where the scanner key comes from (scannerKey, E3 — exactly one source; checked in
    scanner-key-sources.yaml). Secret-based: scannerPrivateKey (the chart writes the Secret),
    existingSecret (yours), or scannerKey.externalSecret / vaultStaticSecret / sealedSecret (your
    operator writes the chart-named Secret). File-based: scannerKey.file.path — the Vault agent
    injector (pod annotations via podAnnotations) or the Secrets Store CSI driver
    (scannerKey.file.csi.secretProviderClass) puts the key there. "true" or "". */}}
{{- define "higgs-scanner.keyFromSecret" -}}
{{- $k := .Values.scannerKey | default dict -}}
{{- if or .Values.scannerPrivateKey .Values.existingSecret.name ($k.externalSecret | default dict).enabled ($k.vaultStaticSecret | default dict).enabled ($k.sealedSecret | default dict).enabled }}true{{ end -}}
{{- end }}
{{- define "higgs-scanner.keyFile" -}}
{{- $f := (.Values.scannerKey | default dict).file | default dict -}}
{{- $f.path | default "" -}}
{{- end }}
{{- define "higgs-scanner.keyCSI" -}}
{{- $f := (.Values.scannerKey | default dict).file | default dict -}}
{{- (($f.csi | default dict).secretProviderClass) | default "" -}}
{{- end }}
{{- define "higgs-scanner.hasKey" -}}
{{- if or (include "higgs-scanner.keyFromSecret" .) (include "higgs-scanner.keyFile" .) }}true{{ end -}}
{{- end }}
{{/* A volume carries the key: the key Secret, or the CSI driver. (The Vault injector mounts its
    own volume — nothing for the chart to add.) */}}
{{- define "higgs-scanner.keyMounted" -}}
{{- if or (include "higgs-scanner.keyFromSecret" .) (include "higgs-scanner.keyCSI" .) }}true{{ end -}}
{{- end }}
{{- define "higgs-scanner.keyFileEnv" -}}
- name: SCANNER_PRIVATE_KEY_FILE
  value: {{ include "higgs-scanner.keyFile" . | default "/etc/higgs/scanner-key/scanner-private-key" }}
{{- if include "higgs-scanner.keyDelivery" . }}
# The key the tenant delivers during a rotation (the scanner-owned delivered-key Secret): held
# while it was delivered on top of the key above (higgs-pkg keydelivery.Effective).
- name: SCANNER_KEY_DELIVERED_DIR
  value: /etc/higgs/scanner-key-delivered
{{- end }}
{{- end }}
{{/* Kubernetes scanners take a rotated key themselves (one-click rotation C1/C2): on whenever the
    scanners have a key and the chart may create the Role for the delivered-key Secret. The
    operator's key store is never written. */}}
{{- define "higgs-scanner.keyDelivery" -}}
{{- $d := (.Values.scannerKey | default dict).delivery | default dict -}}
{{- if and (include "higgs-scanner.hasKey" .) .Values.rbac.create (ne $d.enabled false) }}true{{ end -}}
{{- end }}
{{- define "higgs-scanner.deliveredKeySecretName" -}}
{{- include "higgs-scanner.fullname" . }}-delivered-key
{{- end }}
{{- define "higgs-scanner.keyFileMount" -}}
- name: scanner-key
  mountPath: {{ if include "higgs-scanner.keyFromSecret" . }}/etc/higgs/scanner-key{{ else }}{{ include "higgs-scanner.keyFile" . | dir }}{{ end }}
  readOnly: true
{{- if include "higgs-scanner.keyDelivery" . }}
- name: scanner-key-delivered
  mountPath: /etc/higgs/scanner-key-delivered
  readOnly: true
{{- end }}
{{- end }}
{{- define "higgs-scanner.keyFileVolume" -}}
- name: scanner-key
{{- if include "higgs-scanner.keyFromSecret" . }}
  secret:
    secretName: {{ include "higgs-scanner.secretName" . }}
    items:
      - key: {{ .Values.existingSecret.key | default "scanner-private-key" }}
        path: scanner-private-key
{{- else }}
  csi:
    driver: secrets-store.csi.k8s.io
    readOnly: true
    volumeAttributes:
      secretProviderClass: {{ include "higgs-scanner.keyCSI" . | quote }}
{{- end }}
{{- if include "higgs-scanner.keyDelivery" . }}
# Directory mount (never subPath): kubelet refreshes it when the scanners write a delivered key.
- name: scanner-key-delivered
  secret:
    secretName: {{ include "higgs-scanner.deliveredKeySecretName" . }}
    optional: true
{{- end }}
{{- end }}

{{/*
  Customer pod metadata and env sources (GitOps: the Vault injector, mesh opt-outs, cost labels,
  a Secret/ConfigMap of env). Global values apply to every workload; a component's own block
  adds to them. Selector labels are never overridable — a user label must not break a rollout.
  Call with (dict "root" $ "comp" <component values or nil>).
*/}}
{{- define "higgs-scanner.extraPodLabels" -}}
{{- $comp := .comp | default dict -}}
{{- $l := merge (deepCopy ($comp.podLabels | default dict)) (.root.Values.podLabels | default dict) -}}
{{- $l = omit $l "app" "release" "app.kubernetes.io/component" -}}
{{- if $l }}{{ toYaml $l }}{{ end -}}
{{- end }}

{{- define "higgs-scanner.extraPodAnnotations" -}}
{{- $comp := .comp | default dict -}}
{{- $a := merge (deepCopy ($comp.podAnnotations | default dict)) (.root.Values.podAnnotations | default dict) -}}
{{- if $a }}{{ toYaml $a }}{{ end -}}
{{- end }}

{{- define "higgs-scanner.extraEnvFrom" -}}
{{- with .root.Values.extraEnvFrom }}{{ toYaml . }}{{ end -}}
{{- end }}

{{/*
The validated cluster display name (.Values.clusterName), trimmed; "" when unset. An install with a
name outside 1-63 of [A-Za-z0-9 ._-] fails here with the rule, instead of being shown mangled.
*/}}
{{- define "higgs-scanner.clusterName" -}}
{{- $n := trim (toString (.Values.clusterName | default "")) -}}
{{- if $n -}}
{{- if not (regexMatch "^[A-Za-z0-9 ._-]{1,63}$" $n) -}}
{{- fail (printf "clusterName %q is not allowed: use 1-63 characters of letters, digits, space, '.', '_' or '-'" $n) -}}
{{- end -}}
{{- $n -}}
{{- end -}}
{{- end -}}

{{/*
The admission webhook may never block or stall a customer's pod creation (error-handling review
T1, 2026-10-30): failurePolicy is always Ignore — a different value fails the render with the reason
instead of being honoured — and the timeout is short (default 5 s, at most 10 s; the Kubernetes
default of 10 s held every pod create that long whenever the webhook hung).
*/}}
{{- define "aih-scanner.webhookTimeout" -}}
{{- $fp := .Values.webhook.failurePolicy | default "Ignore" -}}
{{- if ne $fp "Ignore" -}}
{{- fail (printf "webhook.failurePolicy=%s is not supported: the scanner's webhook must never block pod creation, so it is always Ignore (remove the override)" $fp) -}}
{{- end -}}
{{- $t := int (.Values.webhook.timeoutSeconds | default 5) -}}
{{- if or (lt $t 1) (gt $t 10) -}}
{{- fail (printf "webhook.timeoutSeconds=%d must be 1-10" $t) -}}
{{- end -}}
{{- $t -}}
{{- end -}}

{{/*
Capabilities and profiles (chart 3.0.0, plan 2026-11-02-scanner-chart-least-privilege).
Every privileged behaviour is one capability; a profile is a preset of capabilities.
Resolution, strongest first:
  1. an explicitly set 2.x key (proxy.enabled, webhook.enabled, coreDNS.enableLogPlugin,
     upgrader.enabled, agents.enabled) — so a 2.x values file keeps its meaning;
  2. capabilities.<name>;
  3. the profile (monitor | enforce | full; default monitor).
Usage: {{ if include "higgs-scanner.cap" (list $ "proxy") }} — renders "true" or "".
The webhook is installed only together with the proxy or the agents it serves.
*/}}
{{- define "higgs-scanner.capRaw" -}}
{{- $root := index . 0 -}}
{{- $name := index . 1 -}}
{{- $profiles := dict
  "monitor" (dict "capture" true "inventory" true "shadowAI" false "coreDNSPatch" false "onboard" false "adopt" false "podSecurity" false "enforce" false "proxy" false "webhook" false "agents" false "selfUpgrade" false)
  "enforce" (dict "capture" true "inventory" true "shadowAI" false "coreDNSPatch" false "onboard" true "adopt" true "podSecurity" false "enforce" true "proxy" true "webhook" true "agents" false "selfUpgrade" false)
  "full" (dict "capture" true "inventory" true "shadowAI" true "coreDNSPatch" false "onboard" true "adopt" true "podSecurity" true "enforce" true "proxy" true "webhook" true "agents" true "selfUpgrade" false) -}}
{{- $p := $root.Values.profile | default "monitor" -}}
{{- if not (hasKey $profiles $p) -}}
{{- fail (printf "profile %q is not one of: monitor, enforce, full" $p) -}}
{{- end -}}
{{- $preset := index $profiles $p -}}
{{- if not (hasKey $preset $name) -}}
{{- fail (printf "unknown capability %q" $name) -}}
{{- end -}}
{{- $v := index $preset $name -}}
{{- $caps := $root.Values.capabilities | default dict -}}
{{- if and (hasKey $caps $name) (not (kindIs "invalid" (index $caps $name))) -}}
{{- $v = index $caps $name -}}
{{- end -}}
{{- $legacy := dict "proxy" ($root.Values.proxy).enabled "webhook" ($root.Values.webhook).enabled "coreDNSPatch" ($root.Values.coreDNS).enableLogPlugin "selfUpgrade" ($root.Values.upgrader).enabled "agents" ($root.Values.agents).enabled -}}
{{- if and (hasKey $legacy $name) (not (kindIs "invalid" (index $legacy $name))) -}}
{{- $v = index $legacy $name -}}
{{- end -}}
{{- if $v }}true{{ end -}}
{{- end -}}

{{- define "higgs-scanner.cap" -}}
{{- $root := index . 0 -}}
{{- $name := index . 1 -}}
{{- if eq $name "webhook" -}}
{{- if and (include "higgs-scanner.capRaw" (list $root "webhook")) (or (include "higgs-scanner.capRaw" (list $root "proxy")) (include "higgs-scanner.capRaw" (list $root "agents"))) }}true{{ end -}}
{{- else -}}
{{- include "higgs-scanner.capRaw" (list $root $name) -}}
{{- end -}}
{{- end -}}

{{/* The effective capability set, one "name=true|false" per line — the scanner's CAP_* env
     and the render matrix in .gitlab/check-chart.sh both read it. */}}
{{- define "higgs-scanner.capList" -}}
{{- range $n := list "capture" "inventory" "shadowAI" "coreDNSPatch" "onboard" "adopt" "podSecurity" "enforce" "proxy" "webhook" "agents" "selfUpgrade" }}
{{ $n }}={{ if include "higgs-scanner.cap" (list $ $n) }}true{{ else }}false{{ end }}
{{- end }}
{{- end -}}

{{/* /var/run/higgs is a node hostPath only when something outside this pod dials it:
     injected agents, or a standalone proxy DaemonSet. Otherwise a per-pod emptyDir. */}}
{{- define "higgs-scanner.higgsRunHostPath" -}}
{{- if or (include "higgs-scanner.cap" (list . "agents")) (and (include "higgs-scanner.cap" (list . "proxy")) .Values.proxy.standalone) }}true{{ end -}}
{{- end -}}

{{/* The capability ClusterRoles this release renders (clusterrole.yaml / clusterrolebinding.yaml). */}}
{{- define "higgs-scanner.rbacRoles" -}}
{{- $out := list -}}
{{- if include "higgs-scanner.cap" (list . "capture") }}{{ $out = append $out "capture" }}{{ end -}}
{{- if include "higgs-scanner.cap" (list . "inventory") }}{{ $out = append $out "inventory" }}{{ end -}}
{{- if include "higgs-scanner.cap" (list . "shadowAI") }}{{ $out = append $out "shadow-ai" }}{{ end -}}
{{- if or (include "higgs-scanner.cap" (list . "onboard")) (include "higgs-scanner.cap" (list . "podSecurity")) }}{{ $out = append $out "onboard" }}{{ end -}}
{{- if include "higgs-scanner.cap" (list . "adopt") }}{{ $out = append $out "adopt" }}{{ end -}}
{{- if include "higgs-scanner.cap" (list . "enforce") }}{{ $out = append $out "enforce" }}{{ end -}}
{{- if include "higgs-scanner.cap" (list . "proxy") }}{{ $out = append $out "proxy" }}{{ end -}}
{{- $out | toJson -}}
{{- end -}}

{{/* The scanner container's securityContext, derived from the capabilities (see values.yaml). */}}
{{- define "higgs-scanner.scannerSecurityContext" -}}
{{- $sc := deepCopy .Values.securityContext -}}
{{- $enforce := include "higgs-scanner.cap" (list . "enforce") -}}
{{- $add := list "SYS_PTRACE" "SYS_ADMIN" -}}
{{- if or $enforce (include "higgs-scanner.cap" (list . "shadowAI")) -}}
{{- $add = append $add "NET_ADMIN" -}}
{{- end -}}
{{- $userCaps := $sc.capabilities | default dict -}}
{{- $add = concat $add ($userCaps.add | default list) | uniq -}}
{{- $_ := set $sc "capabilities" (dict "add" $add "drop" ($userCaps.drop | default list)) -}}
{{- if kindIs "invalid" $sc.allowPrivilegeEscalation -}}
{{- $_ := set $sc "allowPrivilegeEscalation" (ternary true false (eq $enforce "true")) -}}
{{- end -}}
{{- if kindIs "invalid" $sc.appArmorProfile -}}
{{- $_ := set $sc "appArmorProfile" (dict "type" (ternary "Unconfined" "RuntimeDefault" (eq $enforce "true"))) -}}
{{- end -}}
{{- toYaml $sc -}}
{{- end -}}

{{/* The proxy sidecar's securityContext: the 2.x set (it programs iptables in pod network
     namespaces and binds the node proxy ports). Rendered only with the proxy capability. */}}
{{- define "higgs-scanner.proxySecurityContext" -}}
{{- $sc := deepCopy .Values.securityContext -}}
{{- $userCaps := $sc.capabilities | default dict -}}
{{- $_ := set $sc "capabilities" (dict "add" (concat (list "SYS_PTRACE" "SYS_ADMIN" "NET_ADMIN") ($userCaps.add | default list) | uniq) "drop" ($userCaps.drop | default list)) -}}
{{- if kindIs "invalid" $sc.allowPrivilegeEscalation }}{{ $_ := set $sc "allowPrivilegeEscalation" true }}{{ end -}}
{{- if kindIs "invalid" $sc.appArmorProfile }}{{ $_ := set $sc "appArmorProfile" (dict "type" "Unconfined") }}{{ end -}}
{{- toYaml $sc -}}
{{- end -}}

{{/* The scanner's HTTP bind address: config.host when set; otherwise 127.0.0.1, unless the
     in-process Python agent is on (its HTTP fallback reaches the scanner on the node address). */}}
{{- define "higgs-scanner.host" -}}
{{- if .Values.config.host -}}
{{- .Values.config.host -}}
{{- else if and (include "higgs-scanner.cap" (list . "agents")) .Values.agents.python -}}
0.0.0.0
{{- else -}}
127.0.0.1
{{- end -}}
{{- end -}}

{{/* The prompt-ml classifier (sidecar, pool, config, token) serves the proxy's classifier
     plugin only — nothing else reads it — so it renders only with the proxy capability. */}}
{{- define "higgs-scanner.classifierOn" -}}
{{- if and .Values.classifier.enabled (include "higgs-scanner.cap" (list . "proxy")) }}true{{ end -}}
{{- end -}}
