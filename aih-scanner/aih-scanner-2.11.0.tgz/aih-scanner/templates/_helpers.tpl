{{/* Chart name */}}
{{- define "higgs-scanner.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Fullname: release-chart (with overrides) */}}
{{- define "higgs-scanner.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/* Namespace helper */}}
{{- define "higgs-scanner.namespace" -}}
{{- .Values.namespace.name | default .Release.Namespace }}
{{- end }}

{{/* Chart label value: name-version */}}
{{- define "higgs-scanner.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/* Image tag: prefer .Values.image.tag, fall back to .Chart.AppVersion */}}
{{- define "higgs-scanner.imageTag" -}}
{{- .Values.image.tag | default .Chart.AppVersion }}
{{- end }}

{{/* Resource metadata labels (app.kubernetes.io/*) */}}
{{- define "higgs-scanner.labels" -}}
helm.sh/chart: {{ include "higgs-scanner.chart" . }}
app.kubernetes.io/name: {{ include "higgs-scanner.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ include "higgs-scanner.imageTag" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: aih
{{- end }}

{{/* Pod labels — includes selector labels plus additional metadata */}}
{{- define "higgs-scanner.podLabels" -}}
app: {{ include "higgs-scanner.name" . }}
release: {{ .Release.Name }}
higgs.wallarm.com/name: {{ include "higgs-scanner.name" . }}
higgs.wallarm.com/instance: {{ .Release.Name }}
higgs.wallarm.com/managed-by: {{ .Release.Service }}
higgs.wallarm.com/version: {{ include "higgs-scanner.imageTag" . | quote }}
higgs.wallarm.com/part-of: aih
{{- end }}

{{/* Selector labels for DaemonSet matchLabels — immutable after first deploy.
    Must match the original chart's selectors (app + release) for upgrade compatibility. */}}
{{- define "higgs-scanner.selectorLabels" -}}
app: {{ include "higgs-scanner.name" . }}
release: {{ .Release.Name }}
{{- end }}

{{/* ServiceAccount name */}}
{{- define "higgs-scanner.serviceAccountName" -}}
{{- if .Values.serviceAccount.name }}
{{- .Values.serviceAccount.name }}
{{- else }}
{{- include "higgs-scanner.fullname" . }}
{{- end }}
{{- end }}

{{/* Secret name for scanner private key */}}
{{- define "higgs-scanner.secretName" -}}
{{- if .Values.existingSecret.name }}
{{- .Values.existingSecret.name }}
{{- else }}
{{- printf "%s-private-key" (include "higgs-scanner.fullname" .) }}
{{- end }}
{{- end }}

{{/* Scanner config port (single source of truth) */}}
{{- define "higgs-scanner.port" -}}
{{- .Values.config.port | default 19090 }}
{{- end }}

{{/* Host path to the containerd socket (canonical key: config.containerdSocketPath).
    Falls back to agents.containerdSocketPath, where charts 2.0.0–2.6.0 accidentally
    shipped the key. `required` fails at template time instead of rendering an empty
    hostPath.path that only server-side apply rejects. */}}
{{- define "higgs-scanner.containerdSocketPath" -}}
{{- $agents := .Values.agents | default dict -}}
{{- required "config.containerdSocketPath is required (host path to the containerd socket)" (.Values.config.containerdSocketPath | default $agents.containerdSocketPath) }}
{{- end }}
