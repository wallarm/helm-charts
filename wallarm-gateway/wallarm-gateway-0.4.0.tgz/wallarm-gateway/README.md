# Wallarm Gateway Helm Chart

A Helm chart that installs the [Wallarm Gateway](https://github.com/wallarm/wallarm-api-gateway) Gateway-API controller. The controller watches `GatewayClass` and `Gateway` resources and provisions per-Gateway data planes on demand.

## TL;DR

```bash
helm install my-gateway oci://ghcr.io/wallarm/charts/wallarm-gateway --version 0.4.0
```

## What this chart installs

- One controller `Deployment` (Wallarm Gateway controller)
- One `Service` exposing the controller's WS endpoint to provisioned data planes
- One `ServiceAccount` + `ClusterRole` + `ClusterRoleBinding` for the controller to read Gateway API resources and write owned `Deployments`/`Services`/`Secrets`
- One namespace-scoped `Role` + `RoleBinding` for the controller's leader-election `Lease`
- One `GatewayClass` (`wallarm-gateway`) that the controller reconciles

The chart does NOT install:
- A Gateway resource — you create those (see [first-service.md](../../../docs/getting-started/first-service.md)).
- A data plane Pod or Service — the controller provisions one per Gateway resource.
- Gateway API CRDs — install once per cluster from upstream (see Prerequisites).

## Prerequisites

- Kubernetes >= 1.25
- Helm >= 3.10
- **Gateway API CRDs (required).** Install once per cluster from the upstream release. The chart does not install them — they are shared with any other Gateway API implementation on the cluster.

  ```bash
  kubectl apply -f https://github.com/kubernetes-sigs/gateway-api/releases/download/v1.5.1/standard-install.yaml
  ```

  Supported Gateway API versions: **v1.5.x**.

## Installing

```bash
helm install my-gateway ./deploy/helm/wallarm-gateway \
  --namespace wallarm-system --create-namespace
```

This installs the controller in `wallarm-system`. It registers `GatewayClass/wallarm-gateway` cluster-wide; create `Gateway` resources in any namespace to have data planes provisioned there.

### Verify

```bash
kubectl wait --for=condition=Accepted gatewayclass/wallarm-gateway --timeout=60s
kubectl get deployment -n wallarm-system -l app.kubernetes.io/component=controller
```

### Create your first Gateway

```bash
kubectl apply -f - <<'EOF'
apiVersion: gateway.networking.k8s.io/v1
kind: Gateway
metadata:
  name: demo
  namespace: default
spec:
  gatewayClassName: wallarm-gateway
  listeners:
    - name: http
      port: 80
      protocol: HTTP
EOF

# Watch the controller provision the data plane
kubectl get deployment -n default -l gateway.networking.k8s.io/gateway-name=demo
```

## Bearer-token auth (optional)

By default the WS channel between controller and provisioned data planes is unauthenticated. For production, materialise a shared secret out-of-band (ESO, Vault, SOPS) and reference it:

```bash
helm install my-gateway ./deploy/helm/wallarm-gateway \
  --set gatewaySecret.existingSecret=wallarm-gateway-secret \
  --set gatewaySecret.existingSecretKey=GATEWAY_SECRET
```

The controller propagates the Secret into every Gateway's namespace (Kubernetes prohibits cross-namespace `secretKeyRef`).

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| `image.repository` | string | `wallarm/gateway-controller` | Controller image. |
| `image.tag` | string | `""` | Image tag; defaults to chart `appVersion`. |
| `image.pullPolicy` | string | `IfNotPresent` | Image pull policy. |
| `dataplaneImage` | string | `""` | Image used by the controller for provisioned data planes; defaults to `wallarm/gateway:<appVersion>`. Per-Gateway override via `WallarmGatewayParameters.spec.image`. |
| `imagePullSecrets` | array | `[]` | Image pull secret references. Propagated to provisioned data planes via the controller flag `--default-image-pull-secrets`. |
| `nameOverride` | string | `""` | Override chart-name portion of resource names. |
| `fullnameOverride` | string | `""` | Override the entire generated name. |
| `commonAnnotations` | object | `{}` | Annotations applied to every chart-managed resource. |
| `commonLabels` | object | `{}` | Labels applied to every chart-managed resource. |
| `replicas` | int | `1` | Controller replica count. |
| `gatewayClassName` | string | `wallarm-gateway` | `GatewayClass` name the controller reconciles. |
| `controllerName` | string | `gateway.wallarm.io/wallarm-gateway` | `controllerName` field on the `GatewayClass`. |
| `defaultParametersRef` | string | `""` | Names a cluster-scoped `WallarmGatewayParameters` referenced from `GatewayClass.parametersRef`. Per-Gateway overrides via `Gateway.spec.infrastructure.parametersRef` still win. |
| `publicWsUrl` | string | `""` | Public URL provisioned data planes use to reach the controller WS endpoint. Defaults to the controller Service's cluster-internal DNS. |
| `wsListen` | string | `0.0.0.0:8080` | WS server bind address (controller -> data planes). |
| `healthListen` | string | `0.0.0.0:8081` | Health/readiness HTTP server bind address. |
| `metricsListen` | string | `0.0.0.0:9090` | Prometheus metrics bind address. |
| `leaseName` | string | `wallarm-gateway-controller-lease` | Coordination Lease object name. |
| `gatewaySecret.existingSecret` | string | `""` | Name of an existing Secret holding the WS bearer token. |
| `gatewaySecret.existingSecretKey` | string | `GATEWAY_SECRET` | Key in the existing Secret. |
| `resources` | object | `100m/256Mi -> 1000m/1Gi` | Controller container resources. |
| `podAnnotations` | object | `{}` | Controller pod annotations. |
| `podLabels` | object | `{}` | Controller pod labels. |
| `nodeSelector` | object | `{}` | Controller pod node selector. |
| `tolerations` | array | `[]` | Controller pod tolerations. |
| `affinity` | object | `{}` | Controller pod affinity. |
| `networkPolicy.enabled` | bool | `false` | Create a NetworkPolicy scoped to the controller pod. |
| `networkPolicy.ingress.from` | array | `[]` | Ingress `from` selectors. Empty allows all sources on the controller's WS/health/metrics ports. |
| `networkPolicy.egress.allowDNS` | bool | `true` | Permit cluster-DNS egress. |
| `networkPolicy.egress.extra` | array | `[]` | Additional egress rules. |

## Monitoring

The chart can ship a scrape resource for the controller's `/metrics` endpoint
(named port `metrics`, `9090`). Both flavours are **off by default** and each
is additionally gated by a CRD-availability check, so enabling one on a cluster
without the matching operator is a no-op rather than an install error.

Enable the prometheus-operator `ServiceMonitor`:

```yaml
monitoring:
  serviceMonitor:
    enabled: true
```

Enable the victoriametrics-operator `VMServiceScrape`:

```yaml
monitoring:
  vmServiceScrape:
    enabled: true
```

Both blocks accept `additionalLabels`, `interval`, and `scrapeTimeout`. Relabel
rules are operator-supplied and default to empty — for example, to add an
environment label via the VMServiceScrape:

```yaml
monitoring:
  vmServiceScrape:
    enabled: true
    relabelConfigs:
      - target_label: env
        replacement: production
```

The `ServiceMonitor` uses `relabelings` / `metricRelabelings`; the
`VMServiceScrape` uses `relabelConfigs` / `metricRelabelConfigs`.

## Per-Gateway tuning

Knobs that affect a single provisioned data plane (replicas, resources, securityContext, etc.) live in `WallarmGatewayParameters` CRs, not in this chart's values. See [docs/architecture/gateway-provisioning.md](../../../docs/architecture/gateway-provisioning.md).

## Uninstalling

```bash
helm uninstall my-gateway --namespace wallarm-system
```

Provisioned data planes (`Deployment`, `Service`, `Secret` resources owned by the controller) are NOT automatically deleted when the controller goes away — they remain as orphaned Kubernetes resources until you delete their owning `Gateway`. To clean up:

```bash
# Delete all Gateways referencing this controller; the (now-orphaned) controller's
# children remain until you remove them explicitly.
kubectl delete gateway -A -l gateway.networking.k8s.io/gateway-class=wallarm-gateway
```

## Upgrade notes

### 0.3.x -> 0.4.0

- **Breaking. No upgrade path.** The static data-plane mode is gone. Uninstall any 0.3.x release before installing 0.4.0.
- Removed values: `controller.enabled`, `mode`, `controlPlane.*`, `gateway.*`, `cluster.*`, `service.*`, `headlessService.*`, `ingress.*`, `persistence.*`, `autoscaling.*`, `podDisruptionBudget.*`, `replicaCount`, `strategy`, `revisionHistoryLimit`, `probes.*`, `extraEnv`, `envFrom`, `extraVolumes`, `extraVolumeMounts`, `initContainers`, `sidecars`, `policies.*`, `serviceAccount.*`, `automountServiceAccountToken`, `podSecurityContext`, `securityContext`, `terminationGracePeriodSeconds`, `lifecycle`, `priorityClassName`, `dnsConfig`, `dnsPolicy`, `hostAliases`, `gatewaySecret.value`, `gatewaySecret.oldValue`, `gatewaySecret.existingSecretOldKey`.
- Removed templates: dataplane `Deployment`, `Service`, headless `Service`, `ConfigMap`, `PVC`, `HPA`, `PDB`, `Ingress`, dataplane `ServiceAccount`, Helm-managed `Secret`.
- `controller.*` values hoisted to top level — e.g. `controller.image.repository` is now just `image.repository`.
- Helm test pod removed. The Gateway API conformance suite (`make test-k8s-gwapi-conformance`) is now the contract test.

## Source

- Project: <https://github.com/wallarm/wallarm-api-gateway>
- Issues: <https://github.com/wallarm/wallarm-api-gateway/issues>

## License

Apache-2.0
