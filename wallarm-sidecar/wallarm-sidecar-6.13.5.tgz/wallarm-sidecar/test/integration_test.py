import json
import os
import subprocess
import pytest
import requests
import logging
import shlex
import sysconfig
from time import sleep

logger = logging.getLogger(__name__)

ALLOWED_HTTP_PATH = '/'
FORBIDDEN_HTTP_PATH = '/?id=\'or+1=1--a-<script>prompt(1)</script>\''
SCRIPT_PATH = os.path.dirname(os.path.realpath(__file__))
PATCHES_PATH = f'{SCRIPT_PATH}/kustomize/patches'
WAIT_PODS_TIMEOUT = '180s'

# The INSTALLATION CI job installs the chart as release "wallarm-sidecar" into the "default" namespace.
CHART_NAMESPACE = 'default'
CHART_CREDENTIALS_SECRET = 'wallarm-sidecar-credentials'
# Secret in each test namespace for pods that opt in with the token Secret annotations.
TOKEN_SECRET_NAME = 'wallarm-api-token'
TOKEN_SECRET_KEY = 'token'
TOKEN_SECRET_NAME_ANNOTATION = 'sidecar.wallarm.io/wallarm-api-token-secret-name'

print('PATCHES_PATH: ${PATCHES_PATH}')
patchList = []
for patchPath in os.listdir(PATCHES_PATH):
    patchList.append(patchPath)


class Helpers:
    @staticmethod
    def get_container_logs(namespace: str):
        describe_cmd = f'kubectl describe po -n {namespace} -l wallarm-sidecar=enabled'
        describe = subprocess.run(shlex.split(describe_cmd), capture_output=True, text=True).stdout
        logger.info(f'Describe pods in "{namespace}" namespace: \n\n{describe}')
        logger.info(f'End of describe pod')

        logs_cmd = f'kubectl logs -n {namespace} -l wallarm-sidecar=enabled --all-containers --ignore-errors --since=1h'
        logs = subprocess.run(shlex.split(logs_cmd), capture_output=True, text=True).stdout
        logger.info(f'Logs from "{namespace}" namespace: \n\n{logs}')
        logger.info(f'End of logs')

    @staticmethod
    def subprocess_run(cmd: str, namespace=None) -> subprocess.CompletedProcess:
        logger.info(f'Command: {cmd}')
        completed_process = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
        if completed_process.returncode != 0:
            logger.error(completed_process.stderr)
            if namespace:
                Helpers.get_container_logs(namespace)
            raise Exception(f'Command: {cmd} '
                            f'Exit code: {completed_process.returncode} '
                            f'Stderr: {completed_process.stderr}')
        return completed_process

    @staticmethod
    def create_namespace(namespace: str) -> None:
        cmd = f'kubectl create namespace {namespace}'
        logger.info('Create namespace ...')
        Helpers.subprocess_run(cmd)

    @staticmethod
    def copy_docker_reg(namespace: str, docker_reg_name: str, source_docker_reg_namespace: str) -> None:
        # The Helpers.subprocess_run helper uses shlex.split without shell=True, so shell
        # pipes are not honored. Run the two kubectl calls ourselves and pipe stdout→stdin
        # through Python instead of the shell.
        logger.info(f'Copy {docker_reg_name} from {source_docker_reg_namespace} to {namespace} ...')
        get_cmd = f'kubectl get secret {docker_reg_name} -n {source_docker_reg_namespace} -o yaml'
        get_result = subprocess.run(shlex.split(get_cmd), capture_output=True, text=True)
        if get_result.returncode != 0:
            raise Exception(f'Command: {get_cmd} '
                            f'Exit code: {get_result.returncode} '
                            f'Stderr: {get_result.stderr}')
        patched = get_result.stdout.replace(
            f'namespace: {source_docker_reg_namespace}',
            f'namespace: {namespace}',
        )
        apply_cmd = f'kubectl apply -n {namespace} -f -'
        apply_result = subprocess.run(shlex.split(apply_cmd), input=patched, capture_output=True, text=True)
        if apply_result.returncode != 0:
            raise Exception(f'Command: {apply_cmd} '
                            f'Exit code: {apply_result.returncode} '
                            f'Stderr: {apply_result.stderr}')

    @staticmethod
    def create_token_secret(namespace: str) -> None:
        # Copy the API token from the chart Secret into the test namespace. The manifest
        # goes through stdin, so the token never appears in a logged command line.
        logger.info(f'Create {TOKEN_SECRET_NAME} secret in {namespace} ...')
        get_cmd = f'kubectl -n {CHART_NAMESPACE} get secret {CHART_CREDENTIALS_SECRET} ' \
                  f'-o jsonpath={{.data.WALLARM_API_TOKEN}}'
        token_b64 = Helpers.subprocess_run(get_cmd).stdout.strip()
        manifest = json.dumps({
            'apiVersion': 'v1',
            'kind': 'Secret',
            'metadata': {'name': TOKEN_SECRET_NAME, 'namespace': namespace},
            'type': 'Opaque',
            'data': {TOKEN_SECRET_KEY: token_b64},
        })
        apply_cmd = f'kubectl apply -n {namespace} -f -'
        apply_result = subprocess.run(shlex.split(apply_cmd), input=manifest, capture_output=True, text=True)
        if apply_result.returncode != 0:
            raise Exception(f'Command: {apply_cmd} '
                            f'Exit code: {apply_result.returncode} '
                            f'Stderr: {apply_result.stderr}')

    @staticmethod
    def assert_token_from_secret(namespace: str) -> None:
        # Pods annotated with a token Secret must reference it and carry no plaintext token.
        # Assertions compare booleans only, so a failure never prints the token.
        cmd = f'kubectl -n {namespace} get pods -l wallarm-sidecar=enabled -o json'
        pods = json.loads(Helpers.subprocess_run(cmd).stdout)['items']
        for pod in pods:
            pod_name = pod['metadata']['name']
            secret_name = pod['metadata'].get('annotations', {}).get(TOKEN_SECRET_NAME_ANNOTATION)
            if not secret_name:
                continue
            containers = pod['spec'].get('initContainers', []) + pod['spec']['containers']
            token_envs = [env for c in containers for env in c.get('env', []) if env['name'] == 'WALLARM_API_TOKEN']
            assert len(token_envs) > 0, f'{pod_name}: no container got WALLARM_API_TOKEN'
            for env in token_envs:
                has_literal = 'value' in env
                assert not has_literal, f'{pod_name}: WALLARM_API_TOKEN has a plaintext value'
                ref_name = env.get('valueFrom', {}).get('secretKeyRef', {}).get('name')
                assert ref_name == secret_name, \
                    f'{pod_name}: WALLARM_API_TOKEN references Secret {ref_name}, want {secret_name}'

    @staticmethod
    def create_resources(path: str, namespace: str) -> None:
        cmd = f'kubectl --namespace {namespace} create -k {path}/'
        logger.info('Create resources ...')
        Helpers.subprocess_run(cmd)

    @staticmethod
    def wait_pods(namespace: str) -> None:
        # Need delay here because in some cases we have error: no matching resources found
        sleep(2)
        cmd = f'kubectl --namespace {namespace} ' \
              f'wait --for=condition=Ready pods --all --timeout={WAIT_PODS_TIMEOUT}'
        logger.info('Wait for all Pods ready ...')
        Helpers.subprocess_run(cmd, namespace)

    @staticmethod
    def delete_namespace(namespace: str) -> None:
        cmd = f'kubectl delete namespace {namespace} --ignore-not-found'
        logger.info('Delete namespace ...')
        Helpers.subprocess_run(cmd)

    @staticmethod
    def setup_resources(path: str, namespace: str, docker_reg_name: str, source_docker_reg_namespace: str) -> None:
        Helpers.create_namespace(namespace)
        Helpers.copy_docker_reg(namespace, docker_reg_name, source_docker_reg_namespace)
        Helpers.copy_docker_reg(namespace, 'ci-registry-secret', source_docker_reg_namespace)
        Helpers.create_token_secret(namespace)
        Helpers.create_resources(path, namespace)
        Helpers.wait_pods(namespace)


@pytest.fixture(scope="function")
def helpers():
    return Helpers


@pytest.fixture(scope="function")
def teardown_namespace():
    config = {}
    yield config
    namespace = config['namespace']

    pod_cmd = f"kubectl -n {namespace} get pod -l app=dummy-app -o=name"
    pod_name = subprocess.run(shlex.split(pod_cmd), capture_output=True, text=True).stdout.removeprefix("pod/")
    logger.info(f'Pod name: {pod_name}')

    describe_cmd = f"kubectl -n {namespace} describe pod {pod_name}"
    describe_log = subprocess.run(shlex.split(describe_cmd), capture_output=True, text=True).stdout
    logger.info(f'Pod description: \n{describe_log}')

    log_cmd = f"kubectl -n {namespace} logs {pod_name} --all-containers"
    pod_logs = subprocess.run(shlex.split(log_cmd), capture_output=True, text=True).stdout
    logger.info(f'Pod logs {namespace}: \n{pod_logs}')

    # fyi, this can be commented during testing for debugging purposes
    logger.info(f'Teardown namespace {namespace} ...')
    Helpers.delete_namespace(namespace)


class Tests:
    @pytest.mark.parametrize("config", patchList)
    def test_main_functionality(self, config, helpers, teardown_namespace):
        config_path = f'{PATCHES_PATH}/{config}'
        namespace = config.replace('_', '-')
        base_url = f'http://dummy-app-svc.{namespace}.svc'
        allowed_url = base_url + ALLOWED_HTTP_PATH
        forbidden_url = base_url + FORBIDDEN_HTTP_PATH

        source_docker_reg_namespace = "pytest"
        docker_reg_name = "dockerhub-secret"

        # Register teardown and setup resources for test
        teardown_namespace['namespace'] = namespace

        helpers.setup_resources(config_path, namespace, docker_reg_name, source_docker_reg_namespace)
        helpers.assert_token_from_secret(namespace)

        # Need delay here to ensure that service is ready to send traffic to pods
        sleep(2)

        logger.info(f'Performing allowed request: {allowed_url} ...')
        allowed_request = requests.get(allowed_url)
        assert allowed_request.status_code == 200

        logger.info(f'Performing forbidden request: {forbidden_url} ...')
        forbidden_request = requests.get(forbidden_url)
        assert forbidden_request.status_code == 403
