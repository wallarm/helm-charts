{{/*
Expand the name of the chart.
*/}}
{{- define "wallarm.name" -}}
{{- default "wallarm-node-native" .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "wallarm.fullname" -}}
{{- $name := default "native" .Values.nameOverride -}}
{{- printf "%s" $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create the name for Processing Unit
*/}}
{{- define "processing.fullname" }}
{{- printf "%s-processing" (include "wallarm.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the name for Processing Unit headless service
*/}}
{{- define "processing.discoveryServiceName" }}
{{- printf "processing-discovery" }}
{{- end }}

{{/*
Create the name for Aggregation Unit
*/}}
{{- define "aggregation.fullname" }}
{{- printf "%s-aggregation" (include "wallarm.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the name for Agent Unit
*/}}
{{- define "agent.fullname" }}
{{- printf "%s-agent" (include "wallarm.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the name for shared secret
*/}}
{{- define "wallarm.sharedSecretName" }}
{{- printf "%s-credentials" (include "wallarm.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Main port for Processing unit
*/}}
{{- define "processing.node.ports.main" -}}
18443
{{- end -}}

{{/*
Discovery port for Processing unit
*/}}
{{- define "processing.node.ports.discovery" -}}
9009
{{- end -}}

{{/*
Health port for Processing unit
*/}}
{{- define "processing.node.ports.health" -}}
18080
{{- end -}}


{{/*
wstore port
*/}}
{{- define "aggregation.wstore.port" -}}
3313
{{- end -}}

{{/*
Create the name of the service account for Processing Unit
*/}}
{{- define "processing.serviceAccountName" -}}
{{- if .Values.processing.serviceAccount.name -}}
{{- .Values.processing.serviceAccount.name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{ template "processing.fullname" . }}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account for Aggregation Unit
*/}}
{{- define "aggregation.serviceAccountName" -}}
{{- if .Values.aggregation.serviceAccount.name -}}
{{- .Values.aggregation.serviceAccount.name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{ template "aggregation.fullname" . }}
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "wallarm.labels" -}}
helm.sh/chart: "wallarm-node-native"
helm.sh/version: {{ .Chart.Version | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/name: {{ include "wallarm.name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- if .Values.extraLabels }}
{{ toYaml .Values.extraLabels }}
{{- end }}
{{- end -}}

{{/*
Common annotations
*/}}
{{- define "wallarm.annotations" -}}
{{- if .Values.extraAnnotations -}}
{{- toYaml .Values.extraAnnotations -}}
{{- end -}}
{{- end -}}

{{/*
Annotations for Processing Unit
*/}}
{{- define "processing.annotations" -}}
{{ template "wallarm.annotations" . }}
{{- if .Values.processing.extraAnnotations }}
{{ toYaml .Values.processing.extraAnnotations }}
{{- end }}
{{- end -}}

{{/*
Annotations for Aggregation Unit
*/}}
{{- define "aggregation.annotations" -}}
{{ template "wallarm.annotations" . }}
{{- if .Values.aggregation.extraAnnotations }}
{{ toYaml .Values.aggregation.extraAnnotations }}
{{- end }}
{{- end -}}

{{/*
Labels for Processing Unit
*/}}
{{- define "processing.labels" -}}
{{ template "wallarm.labels" . }}
{{ template "processing.selectorLabels" . }}
{{- if .Values.processing.extraLabels }}
{{ toYaml .Values.processing.extraLabels }}
{{- end }}
{{- end -}}

{{/*
Labels for Processing Metrics Server
*/}}
{{- define "processing.metricsService.labels" -}}
{{ template "wallarm.labels" . }}
{{ template "processing.metricsService.selectorLabels" . }}
{{- if .Values.processing.metrics.service.extraLabels }}
{{- toYaml .Values.processing.metrics.service.extraLabels }}
{{- end }}
{{- end -}}

{{/*
Labels for Aggregation Unit
*/}}
{{- define "aggregation.labels" -}}
{{ template "wallarm.labels" . }}
{{ template "aggregation.selectorLabels" . }}
{{- if .Values.aggregation.extraLabels }}
{{ toYaml .Values.aggregation.extraLabels }}
{{- end }}
{{- end -}}


{{/*
Selector labels for Processing Unit
*/}}
{{- define "processing.selectorLabels" -}}
app.kubernetes.io/component: "processing"
{{- end -}}

{{/*
Selector labels for Processing Metrics Service
*/}}
{{- define "processing.metricsService.selectorLabels" -}}
app.kubernetes.io/component: "processing-metrics"
{{- end -}}

{{/*
Selector labels for Aggregation Unit
*/}}
{{- define "aggregation.selectorLabels" -}}
app.kubernetes.io/component: "aggregation"
{{- end -}}


{{/*
Docker image name
*/}}
{{- define "image" -}}
{{- if .fullname -}}
{{- printf "%s" .fullname -}}
{{- else -}}
{{- if .registry -}}
{{- printf "%s/%s:%s" .registry .name .tag -}}
{{- else -}}
{{- printf "%s:%s" .name .tag -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "wallarm.credentials" -}}
- name: WALLARM_API_HOST
  valueFrom:
    secretKeyRef:
      key: WALLARM_API_HOST
      name: {{ template "wallarm.sharedSecretName" . }}
- name: WALLARM_API_PORT
  valueFrom:
    secretKeyRef:
      key: WALLARM_API_PORT
      name: {{ template "wallarm.sharedSecretName" . }}
- name: WALLARM_API_USE_SSL
  valueFrom:
    secretKeyRef:
      key: WALLARM_API_USE_SSL
      name: {{ template "wallarm.sharedSecretName" . }}
- name: WALLARM_API_TOKEN
  valueFrom:
    secretKeyRef:
      key: WALLARM_API_TOKEN
      name: {{ template "wallarm.sharedSecretName" . }}
- name: WALLARM_COMPONENT_NAME
  value: wallarm-node-native
- name: WALLARM_COMPONENT_VERSION
  value: {{ .Chart.Version | quote }}
- name: WALLARM_NODE_NATIVE_HELM_CHART_COMPONENT_NAME
  value: node-native-helm-chart
- name: WALLARM_NODE_NATIVE_HELM_CHART_COMPONENT_VERSION
  value: {{ .Chart.Version | quote }}
- name: WALLARM_NODE_DEPLOYMENT_TYPE
  value: node-native-helm-chart
- name: WALLARM_NODE_NAME
  valueFrom:
    fieldRef:
      fieldPath: metadata.name
{{- if hasKey .Values.config.api "caVerify" }}
- name: WALLARM_API_CA_VERIFY
  value: {{ .Values.config.api.caVerify | toString | quote }}
{{- end }}
{{- if .Values.config.api.nodeGroup }}
- name: WALLARM_LABELS
  value: "group={{ .Values.config.api.nodeGroup }}"
{{- end }}
{{- end -}}


{{/*
Default SecurityContext
*/}}
{{- define "wallarm.defaultSecurityContext" -}}
allowPrivilegeEscalation: false
privileged: false
runAsUser: 101
runAsNonRoot: true
seccompProfile:
    type: RuntimeDefault
capabilities:
  drop:
  - ALL
{{- end -}}

{{/*
Wallarm Node SecurityContext
*/}}
{{- define "wallarm.serviceSecurityContext" -}}
allowPrivilegeEscalation: false
privileged: false
runAsUser: 101
runAsNonRoot: true
seccompProfile:
    type: RuntimeDefault
capabilities:
  drop:
    - ALL
  add:
    - NET_BIND_SERVICE
{{- end -}}

{{/*
Wcli arguments building
*/}}
{{- define "wallarm.wcli-args" -}}
"-log-level", "{{ .Values.config.wcli.logLevel }}",{{ " " }}
{{- with .Values.config.wcli.commands -}}
{{- range $name, $value := . -}}
"job:{{ $name }}", "-log-level", "{{ $value.logLevel }}",{{ " " }}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create the name for certificate secret
*/}}
{{- define "wallarm.certificateSecretName" -}}
{{- if .Values.config.connector.certificate.existingSecret.enabled -}}
{{- .Values.config.connector.certificate.existingSecret.name -}}
{{- else -}}
{{ template "processing.fullname" . }}-node-tls
{{- end -}}
{{- end -}}


{{- define "wallarm.wstoreVariables" -}}
- name: SLAB_ALLOC_ARENA
  value: "{{ .Values.config.aggregation.wstoreMemory }}"
- name: WALLARM_WSTORE__METRICS__LISTEN_ADDRESS
  value: "{{ .Values.config.aggregation.metrics.listenAddress }}"
- name: WALLARM_WSTORE__METRICS__PROTOCOL
  value: "{{ .Values.config.aggregation.metrics.protocol }}"
- name: WALLARM_WSTORE__SERVICE__ADDRESS
  value: "{{ .Values.config.aggregation.serviceAddress }}"
- name: WALLARM_WSTORE__SERVICE__PROTOCOL
  value: "{{ .Values.config.aggregation.serviceProtocol }}"
{{- end -}}

{{/*
API configuration data helper
*/}}
{{- define "wallarm.sharedSecretData" -}}
WALLARM_API_TOKEN: {{ .Values.config.api.token | b64enc | quote }}
WALLARM_API_HOST: {{ .Values.config.api.host | b64enc | quote }}
WALLARM_API_PORT: {{ .Values.config.api.port | toString | b64enc | quote }}
WALLARM_API_USE_SSL: {{ .Values.config.api.useSSL | toString | b64enc | quote }}
{{- end -}}

{{/*
Go-node configuration template
*/}}
{{- define "wallarm.goNodeConfig" -}}
version: 4
mode: {{ .Values.config.connector.mode }}

{{ if ne .Values.config.connector.mode "envoy-external-filter" }}
connector:
  {{- if or (gt (int .Values.processing.replicaCount) 1) (.Values.processing.autoscaling.enabled) }}
  {{- if not .Values.config.connector.disable_mesh }}
  mesh:
    discovery: dns
    name: {{ template "processing.discoveryServiceName" . }}
    port: {{ template "processing.node.ports.discovery" . }}
  {{- end }}
  {{- end }}

  address: ":{{ template "processing.node.ports.main" . }}"

  {{- if .Values.config.connector.certificate.enabled }}
  tls_cert: /opt/wallarm/certs/tls.crt
  tls_key: /opt/wallarm/certs/tls.key
  {{- end }}

  allowed_networks:
    - 0.0.0.0/0
  {{- with .Values.config.connector.allowed_hosts }}
  allowed_hosts: {{ . | toYaml | nindent 4 }}
  {{- end }}

  {{- with .Values.config.connector.per_connection_limits }}
  per_connection_limits:
    {{ . | toYaml | nindent 4 }}
  {{- end }}
{{ else }}
envoy_external_filter:
  address: ":{{ template "processing.node.ports.main" . }}"
  {{- if not .Values.config.connector.certificate.enabled }}
  {{- fail "Error. Certificates are MANDATORY for this mode! Please remember to enable config.connector.certificate.enabled in chart values AND one of the certificate provisioning modes just below it" -}}
  {{- end }}
  tls_cert: /opt/wallarm/certs/tls.crt
  tls_key: /opt/wallarm/certs/tls.key
{{ end }}

route_config:
  {{ toYaml .Values.config.connector.route_config | nindent 2 }}

proxy_headers:
  {{ toYaml .Values.config.connector.proxy_headers | nindent 2 }}

input_filters:
  {{ toYaml .Values.config.connector.input_filters | nindent 2 }}

http_inspector:
  {{ toYaml .Values.config.connector.http_inspector | nindent 2 }}

postanalytics_exporter:
  address: "{{ template "aggregation.fullname" . }}:{{ template "aggregation.wstore.port" . }}"

health_check:
  enabled: true
  listen_address: :{{ template "processing.node.ports.health" . }}

metrics:
  enabled: {{ .Values.processing.metrics.enabled }}
  listen_address: :{{ .Values.processing.metrics.port }}
  {{- with .Values.processing.metrics.cloud_export }}
  cloud_export:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  legacy_status:
    listen_address: "127.0.0.1:10246"

log:
  {{ toYaml .Values.config.connector.log | nindent 2 }}
{{- end -}}

